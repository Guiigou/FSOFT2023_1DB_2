
//#include "controller/WarehouseController.h"


//TEST(WarehouseControllerTest, removeProduct) {
    //WarehouseController warehouse;
    // Verificar se o produto "####" foi removido corretamente
//}


//TEST(WarehouseControllerTest, RemoveNonExistingProduct) {
    //WarehouseController warehouse;
    //Verifique se um produto inexistente não é removido
//}


//TEST(WarehouseControllerTest, BuyFromSupplier) {
    //WarehouseController warehouse;
    // Verificar se o produto foi comprado do fornecedor corretamente
//}


//TEST(WarehouseControllerTest, BuyFromSupplierNonExistingProduct) {
    //WarehouseController warehouse;
    // Verifique se um produto inexistente não é comprado do fornecedor
//}

