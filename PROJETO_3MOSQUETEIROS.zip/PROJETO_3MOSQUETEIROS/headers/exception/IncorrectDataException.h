//
// Created by guilh on 15/06/2023.
//

#ifndef PROJETO3MOSQUETEIROS_INCORRECTDATAEXCEPTION_H
#define PROJETO3MOSQUETEIROS_INCORRECTDATAEXCEPTION_H

#include <exception>
#include <string>
using namespace std;

class IncorrectDataException : public std::exception {
private:
    std::string message;

public:
    explicit IncorrectDataException(const std::string& message);

    const char* what() const noexcept override;
};



#endif //PROJETO3MOSQUETEIROS_INCORRECTDATAEXCEPTION_H
