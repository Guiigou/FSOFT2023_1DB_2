
#ifndef PROJETO3MOSQUETEIROS_INVALIDOPTIONEXCEPTION_H
#define PROJETO3MOSQUETEIROS_INVALIDOPTIONEXCEPTION_H

#include <stdexcept>

#include <string>

using namespace std;
class InvalidOptionException : public std::exception {
private:
    int option;
    string message;

public:
    InvalidOptionException(int option);

    const char* what() const noexcept override;
};
#endif //PROJETO3MOSQUETEIROS_INVALIDOPTIONEXCEPTION_H
