#ifndef PROJETO3MOSQUETEIROS_ACCOUNTINGVIEW_H
#define PROJETO3MOSQUETEIROS_ACCOUNTINGVIEW_H

#include "../controller/AccountingController.h"
using namespace std;

class AccountingView {
public:
    static void showAccountingMenu(AccountingController& accountingController);
};

#endif //PROJETO3MOSQUETEIROS_ACCOUNTINGVIEW_H
