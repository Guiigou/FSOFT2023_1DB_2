//
// Created by guilh on 30/05/2023.
//

#ifndef PROJETO3MOSQUETEIROS_MENU_H
#define PROJETO3MOSQUETEIROS_MENU_H

class Menu {
public:
    static void showMainMenu();
};

#endif //PROJETO3MOSQUETEIROS_MENU_H
