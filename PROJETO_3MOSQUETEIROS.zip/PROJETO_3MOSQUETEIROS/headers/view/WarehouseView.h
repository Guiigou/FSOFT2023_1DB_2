#ifndef PROJETO3MOSQUETEIROS_WAREHOUSEVIEW_H
#define PROJETO3MOSQUETEIROS_WAREHOUSEVIEW_H

#include "../controller/WarehouseController.h"
using namespace std;

class WarehouseView {
public:
    static void showWarehouseMenu(WarehouseController& warehouseController);
};

#endif //PROJETO3MOSQUETEIROS_WAREHOUSEVIEW_H
