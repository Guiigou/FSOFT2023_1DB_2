#ifndef PROJETO3MOSQUETEIROS_EMPLOYEEVIEW_H
#define PROJETO3MOSQUETEIROS_EMPLOYEEVIEW_H

#include "../controller/EmployeeController.h"
using namespace std;

class EmployeeView {
public:
    static void showEmployeeMenu(EmployeeController& employeeController);
};

#endif //PROJETO3MOSQUETEIROS_EMPLOYEEVIEW_H
