//
// Created by guilh on 08/06/2023.
//

#ifndef PROJETO3MOSQUETEIROS_SUPPLIERVIEW_H
#define PROJETO3MOSQUETEIROS_SUPPLIERVIEW_H

#include "../controller/SupplierController.h"

using namespace std;

class SupplierView {
public:
    static void showSupplierMenu(SupplierController& supplierController);
};

#endif //PROJETO3MOSQUETEIROS_SUPPLIERVIEW_H
