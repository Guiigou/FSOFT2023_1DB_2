#include <iostream>
#include "../../headers/view/AccountingView.h"

#include "../../headers/exception/InvalidOptionException.h"
#include "../../headers/exception/IncorrectDataException.h"

void AccountingView::showAccountingMenu(AccountingController& accountingController) {
    int option;

    do {
        cout << "==== Menu de Contabilidade ====" << endl;
        cout << "1. Registrar compra do fornecedor" << endl;
        cout << "2. Registrar retirada de produtos do armazem" << endl;
        cout << "3. Visualizar registro de compras e retiros de produtos" << endl;
        cout << "0. Voltar" << endl;
        cout << "===============================" << endl;
        cout << "Escolha uma opcao: ";
        cin >> option;
        cin.ignore();

        try{
            switch (option) {
                case 1: {
                    std::string productID;
                    int quantity;
                    double purchasePrice;

                    cout << "==== Registrar Compra do Fornecedor ====" << endl;
                    cout << "Digite o ID do produto comprado: ";
                    getline(std::cin, productID);
                        if (productID != "R001" && productID != "M001" && productID != "T001"
                            && productID != "PM001" && productID != "PG001")
                        {
                            throw IncorrectDataException("Preenchimento de informacoes incorreto!");
                        }

                    cout << "Digite a quantidade comprada: ";
                    cin >> quantity;
                        if (quantity < 0)
                        {
                            throw IncorrectDataException("Preenchimento de informacoes incorreto!");
                        }

                    cout << "Digite o preco de compra: ";
                    cin >> purchasePrice;

                    cin.ignore();

                    PurchaseRecord purchaseRecord(productID, quantity, purchasePrice);
                    accountingController.addPurchaseRecord(purchaseRecord);

                    cout << "Compra registrada com sucesso!" << endl;
                    break;
                }
                case 2: {
                    std::string productID;
                    int quantity;
                    double purchasePrice;

                    cout << "==== Registrar Retirada de Produtos do Armazem ====" << endl;
                    cout << "Digite o ID do produto retirado: ";
                    getline(std::cin, productID);
                        if (productID != "R001" && productID != "M001" && productID != "T001"
                            && productID != "PM001" && productID != "PG001")
                        {
                            throw IncorrectDataException("Preenchimento de informacoes incorreto!");
                        }

                    cout << "Digite a quantidade retirada: ";
                    cin >> quantity;
                        if (quantity < 0)
                        {
                            throw IncorrectDataException("Preenchimento de informacoes incorreto!");
                        }

                    cout << "Digite o preço de compra: ";
                    cin >> purchasePrice;
                    cin.ignore();

                    PurchaseRecord purchaseRecord(productID, quantity, purchasePrice);
                    accountingController.addPurchaseRecord(purchaseRecord);

                    cout << "Retirada registrada com sucesso!" << endl;
                    break;
                }
                case 3: {
                    accountingController.listPurchaseRecords();
                    break;
                }
                case 0: {
                    cout << "Voltando ao menu principal..." << endl;
                    break;
                }
                default: {
                    throw InvalidOptionException(option);
                }
            }
        } catch (const InvalidOptionException& e) {
            std::cout << "Erro: " << e.what() << std::endl;
        }

        cout << endl;
    } while (option != 0);
}