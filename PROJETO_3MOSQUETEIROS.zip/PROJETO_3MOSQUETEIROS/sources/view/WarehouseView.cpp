#include <iostream>
#include "../../headers/view/WarehouseView.h"
#include "../../headers/exception/InvalidOptionException.h"
#include "../../headers/exception/IncorrectDataException.h"


void WarehouseView::showWarehouseMenu(WarehouseController& warehouseController) {

    int option;

    do {
        cout << "==== Menu do Armazém ====" << std::endl;
        cout << "1. Comprar produtos do fornecedor" << std::endl;
        cout << "2. Listar produtos disponíveis no armazém" << std::endl;
        cout << "3. Retirar produtos do armazém" << std::endl;
        cout << "0. Voltar" << std::endl;
        cout << "==========================" << std::endl;
        cout << "Escolha uma opção: ";
        cin >> option;
        cin.ignore();

        try {
            switch (option) {
                case 1: {
                    string productName;
                    string productID;
                    string productDescription;
                    int productQuantity;
                    double productPurchasePrice;
                    double productSellingPrice;

                    cout << "==== Comprar Produtos do Fornecedor ====" << std::endl;
                    cout << "Digite as informacoes do produto:" << std::endl;
                    cout << "Nome: ";
                    getline(std::cin, productName);
                        if (productName != "Rato" && productName != "Monitor" && productName != "Teclado"
                            && productName != "Placa grafica" && productName != "Placa mae")
                            {
                                throw IncorrectDataException("Preenchimento de informacoes incorreto!");
                            }

                    cout << "ID: ";
                    getline(std::cin, productID);
                        if (productID != "R001" && productID != "M001" && productID != "T001"
                            && productID != "PM001" && productID != "PG001")
                        {
                            throw IncorrectDataException("Preenchimento de informacoes incorreto!");
                        }

                    cout << "Descricao: ";
                    getline(std::cin, productDescription);
                        if (productDescription != "Blue Switches | Mecanico | 75%" && productDescription != "24 polegadas" && productDescription != "Wireless"
                        && productDescription != "RTX 3080 NVIDIA" && productDescription != "ASUS")
                        {
                            throw IncorrectDataException("Preenchimento de informacoes incorreto!");
                        }

                    cout << "Quantidade: ";
                    cin >> productQuantity;
                        if (productQuantity < 0)
                        {
                            throw IncorrectDataException("Preenchimento de informacoes incorreto!");
                        }

                    cout << "Preco de compra: ";
                    cin >> productPurchasePrice;

                    cout << "Preco de venda: ";
                    cin >> productSellingPrice;

                    cin.ignore();

                    Product newProduct(productName, productID, productDescription, productQuantity,
                                       productPurchasePrice, productSellingPrice);
                    warehouseController.buyFromSupplier(newProduct, productQuantity);

                    cout << "Produto comprado do fornecedor com sucesso!" << std::endl;
                    break;
                }
                case 2: {
                    warehouseController.listProducts();
                    break;
                }
                case 3: {
                    std::string productID;
                    int quantity;

                    cout << "==== Retirar Produtos do Armazem ====" << std::endl;
                    cout << "Digite o ID do produto que deseja retirar: ";
                    getline(std::cin, productID);
                    cout << "Digite a quantidade a ser retirada: ";
                    cin >> quantity;
                    cin.ignore();

                    warehouseController.removeProduct(productID, quantity);

                    cout << "Produto retirado do armazém com sucesso!" << std::endl;
                    break;
                }
                case 0: {
                    cout << "Voltando ao menu principal..." << std::endl;
                    break;
                }
                default: {
                    throw InvalidOptionException(option);
                }
            }
        }catch (const InvalidOptionException& e) {
            cout << e.what() << endl;
        }

        cout << std::endl;
    } while (option != 0);
}