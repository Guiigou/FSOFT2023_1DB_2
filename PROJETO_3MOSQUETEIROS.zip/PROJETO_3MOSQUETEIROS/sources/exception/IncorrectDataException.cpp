#include "../../headers/exception/IncorrectDataException.h"

IncorrectDataException::IncorrectDataException(const std::string& message)
        : message(message) {}

const char* IncorrectDataException::what() const noexcept {
    return message.c_str();
}