#include "../../headers/exception/InvalidOptionException.h"

InvalidOptionException::InvalidOptionException(int option) : option(option) {
    message = "| Erro | " + to_string(option) + " --> invalido!!";
}

const char* InvalidOptionException::what() const noexcept {
    return message.c_str();
}