
#include "../../headers/controller/WarehouseController.h"
#include <iostream>

WarehouseController::WarehouseController() {

    // Exemplo de produtos já existentes no armazém
    products.push_back(Product("Teclado", "T001", "Blue Switches | Mecanico | 75%", 6, 50.0, 100.0));
    products.push_back(Product("Monitor", "M001", "24 polegadas", 5, 200.0, 300.0));
    products.push_back(Product("Rato", "R001", "Wireless", 10, 20.0, 40.0));
    products.push_back(Product("Placa grafica", "PG001", "RTX 3080 NVIDIA", 5, 500.0, 800.0));
    products.push_back(Product("Placa mae", "PM001", "ASUS", 5, 150.0, 250.0));
}


void WarehouseController::removeProduct(const std::string& productID, int quantity) {
    for (auto it = products.begin(); it != products.end(); ++it) {
        if (it->getID() == productID) {
            it->setQuantity(it->getQuantity() - quantity);
            if (it->getQuantity() <= 0) {
                products.erase(it);
            }
            break;
        }
    }
}

void WarehouseController::listProducts() const {
    if (products.empty()) {
        std::cout << "Nenhum produto disponivel no armazem." << std::endl;
    } else {
        std::cout << "Produtos disponiveis no armazem:" << std::endl;
        for (const auto& product : products) {
            std::cout << "Nome: " << product.getName() << std::endl;
            std::cout << "ID: " << product.getID() << std::endl;
            std::cout << "Descricao: " << product.getDescription() << std::endl;
            std::cout << "Quantidade: " << product.getQuantity() << std::endl;
            std::cout << "Preco de compra: " << product.getPurchasePrice() << std::endl;
            std::cout << "Preco de venda: " << product.getSellingPrice() << std::endl;
            std::cout << "----------------------------------------" << std::endl;
        }
    }
}




void WarehouseController::buyFromSupplier(const Product& product, int quantity) {
    for (auto& p : products) {
        if (p.getID() == product.getID()) {
            p.setQuantity(p.getQuantity() + quantity);
            break;
        }
    }
}